from flask import Blueprint, render_template, request, flash, jsonify
from flask_login import login_required, current_user
from .models import Note, Beställning
from . import db
import json
import pandas as pd




views = Blueprint('views', __name__)

@views.route('/', methods=['GET', 'POST'])
def home():
    

    return render_template("home.html", user=current_user)



@views.route('/meny', methods=['GET', 'POST'])
def meny():
    if request.method =='POST':
        button = request.form['button']
        if button == 'button1':
            beställning = Beställning(name = 'Margherita', toppings='Tomato, mozarella, basil', price= 10)
            flash('Du har beställt Margherita!', category='success')
        elif button == 'button2':
            beställning = Beställning(name = 'Pepperoni', toppings='Tomato, mozarella, pepperoni', price = 11)
            flash('Du har beställt Pepperoni!', category='success')
        elif button == 'button3':
            beställning = Beställning(name = 'Hawaii', toppings='Tomato sauce, mozarella, mushrooms, olives, peppers', price = 11)
            flash('Du har beställt Hawaii!', category='success')
        elif button == 'button4':
            beställning = Beställning(name = 'Vegetarian', toppings='Tomato sauce, mozzarella, mushrooms, olives, peppers', price = 11)
            flash('Du har beställt Vegetarian!', category='success')
        elif button == 'button5':
            beställning = Beställning(name = 'Seafood', toppings='Tomato sauce, mozzarella, shrimp, crab, tuna', price = 12)
            flash('Du har beställt Seafood!', category='success')
        elif button == 'button6':
            beställning = Beställning(name = 'Carbonara', toppings='Tomato sauce, mozzarella, bacon, egg', price = 12)
            flash('Du har beställt Carbonara!', category='success')
        elif button == 'button7':
            beställning = Beställning(name = 'Quattro Stagioni', toppings='Tomato sauce, mozzarella, ham, mushrooms, artichokes, olives', price = 12)
            flash('Du har beställt Quattro Stagioni!', category='success')
        elif button == 'button8':
            beställning = Beställning(name = 'Quattro Formaggi', toppings='Tomato sauce, mozzarella, gorgonzola, parmesan, emmental', price = 12)
            flash('Du har beställt Quattro Formaggi!', category='success')
        elif button == 'button9':
            beställning = Beställning(name = 'Napoli', toppings='Tomato sauce, mozzarella, anchovies, capers', price = 13)
            flash('Du har beställt Napoli!', category='success')
        elif button == 'button10':
            beställning = Beställning(name = 'Calzone', toppings='Tomato sauce, mozzarella, ham, mushrooms, peppers', price = 13)
            flash('Du har beställt Calzone!', category='success')
        db.session.add(beställning)
        db.session.commit()
    pizzameny = pd.read_csv('pizzeria.csv')
    return render_template('/meny.html',tables =[pizzameny.to_html()], titles=[' '])

@views.route('/admin')
def admin():
    beställningar = Beställning.query.all()
    return render_template('/admin.html', beställningar = beställningar)


